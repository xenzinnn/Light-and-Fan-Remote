package com.example.irhomeremote

/**
 * Replace each empty IntArray with the raw pulse-duration pattern (microseconds)
 * captured from the ORIGINAL remote for your specific appliance.
 *
 * Example shape only (NOT a working code for your device):
 * intArrayOf(9000, 4500, 560, 560, 560, 1690, ...)
 *
 * Capture with a compatible IR-learning device/app or obtain the protocol/code
 * from the appliance manufacturer. Do not use the example above as a real command.
 *
 * Android ConsumerIrManager.transmit() expects alternating mark/space durations
 * in microseconds. Typical carrier frequency is 38,000 Hz, but your remote may differ.
 */
object IrCommands {
    const val carrierFrequencyHz = 38_000

    val lightOn = intArrayOf()
    val lightOff = intArrayOf()

    // Warm / neutral / cool presets selected by the temperature slider.
    val lightWarm = intArrayOf()
    val lightNeutral = intArrayOf()
    val lightCool = intArrayOf()

    // Brightness positions from 0% to 100% in 10% increments (11 entries).
    // Add one captured command per supported level. If your lamp uses +/- commands,
    // this app will need a device-specific repeat/step implementation instead.
    val brightnessSteps: List<IntArray> = listOf(
        intArrayOf(), intArrayOf(), intArrayOf(), intArrayOf(), intArrayOf(),
        intArrayOf(), intArrayOf(), intArrayOf(), intArrayOf(), intArrayOf(),
        intArrayOf()
    )

    val fanOn = intArrayOf()
    val fanOff = intArrayOf()
    val fanLevel1 = intArrayOf()
    val fanLevel2 = intArrayOf()
    val fanLevel3 = intArrayOf()
}
