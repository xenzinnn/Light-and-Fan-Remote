package com.example.irhomeremote

import android.app.Activity
import android.content.Context
import android.hardware.ConsumerIrManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Typeface

/**
 * IR Home Remote starter app.
 *
 * IMPORTANT: The raw IR pulse patterns in IrCommands are intentionally empty.
 * Replace them with pulse patterns captured from your actual light/fan remote.
 * IR commands are appliance-specific; guessed codes won't reliably control devices.
 */
class MainActivity : Activity() {
    private lateinit var ir: ConsumerIrManager
    private lateinit var status: TextView
    private lateinit var lightSwitch: Switch
    private lateinit var fanSwitch: Switch
    private lateinit var fanLevel: SeekBar
    private lateinit var tempSlider: SeekBar
    private lateinit var brightnessSlider: SeekBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ir = getSystemService(Context.CONSUMER_IR_SERVICE) as ConsumerIrManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(18), dp(22), dp(20))
            setBackgroundColor(0xFFF4F5F7.toInt())
        }

        root.addView(TextView(this).apply {
            text = "IR Home Remote"
            textSize = 28f
            setTextColor(0xFF172033.toInt())
            typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Control your lights and fan"
            textSize = 15f
            setTextColor(0xFF626B7A.toInt())
            setPadding(0, dp(3), 0, dp(18))
        })

        val hardware = if (ir.hasIrEmitter()) "IR blaster detected" else "No IR blaster detected on this phone"
        status = TextView(this).apply {
            text = "$hardware\nAdd your device's IR codes to enable control."
            textSize = 13f
            setTextColor(if (ir.hasIrEmitter()) 0xFF276749.toInt() else 0xFFB42318.toInt())
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(0xFFE8EBF0.toInt())
        }
        root.addView(status, marginParams(bottom = 16))

        root.addView(sectionTitle("LIGHTS"))
        lightSwitch = Switch(this).apply {
            text = "Power"
            textSize = 17f
            setPadding(0, dp(8), 0, dp(8))
            setOnCheckedChangeListener { _, isChecked ->
                send(if (isChecked) IrCommands.lightOn else IrCommands.lightOff, "Light ${if (isChecked) "ON" else "OFF"}")
            }
        }
        root.addView(lightSwitch, marginParams(bottom = 8))

        root.addView(label("Color temperature"))
        root.addView(TextView(this).apply {
            text = "Warm  ←────────────→  Cool"
            textSize = 12f
            setTextColor(0xFF626B7A.toInt())
        })
        tempSlider = SeekBar(this).apply {
            max = 100
            progress = 25
            setOnSeekBarChangeListener(listener { progress ->
                // Many lamps use discrete warm/neutral/cool commands. Map these positions
                // to the corresponding captured commands in sendTemperature().
                sendTemperature(progress)
            })
        }
        root.addView(tempSlider, marginParams(bottom = 12))

        root.addView(label("Brightness"))
        brightnessSlider = SeekBar(this).apply {
            max = 100
            progress = 75
            setOnSeekBarChangeListener(listener { progress ->
                sendBrightness(progress)
            })
        }
        root.addView(brightnessSlider, marginParams(bottom = 18))

        root.addView(sectionTitle("FAN"))
        fanSwitch = Switch(this).apply {
            text = "Power"
            textSize = 17f
            setPadding(0, dp(8), 0, dp(8))
            setOnCheckedChangeListener { _, isChecked ->
                send(if (isChecked) IrCommands.fanOn else IrCommands.fanOff, "Fan ${if (isChecked) "ON" else "OFF"}")
            }
        }
        root.addView(fanSwitch, marginParams(bottom = 8))

        root.addView(label("Fan strength"))
        root.addView(TextView(this).apply {
            text = "Level 1  •  Level 2  •  Level 3"
            textSize = 12f
            setTextColor(0xFF626B7A.toInt())
        })
        fanLevel = SeekBar(this).apply {
            max = 2
            progress = 1
            setOnSeekBarChangeListener(listener { progress ->
                val level = progress + 1
                val command = when (level) {
                    1 -> IrCommands.fanLevel1
                    2 -> IrCommands.fanLevel2
                    else -> IrCommands.fanLevel3
                }
                send(command, "Fan level $level")
            })
        }
        root.addView(fanLevel, marginParams(bottom = 16))

        val note = TextView(this).apply {
            text = "Setup note: This app needs the exact IR commands for your light and fan. The sliders send commands when released; some devices support only preset steps rather than smooth adjustment."
            textSize = 12f
            setTextColor(0xFF626B7A.toInt())
        }
        root.addView(note)

        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private fun sendTemperature(value: Int) {
        val command = when {
            value < 34 -> IrCommands.lightWarm
            value < 67 -> IrCommands.lightNeutral
            else -> IrCommands.lightCool
        }
        send(command, "Color temperature")
    }

    private fun sendBrightness(value: Int) {
        // Default mapping sends one captured step command per 10% change.
        val step = ((value / 10).coerceIn(0, 10))
        send(IrCommands.brightnessSteps.getOrNull(step) ?: intArrayOf(), "Brightness ${step * 10}%")
    }

    private fun send(pattern: IntArray, action: String) {
        if (!ir.hasIrEmitter()) {
            status.text = "This phone does not report an IR emitter. Controls cannot transmit."
            return
        }
        if (pattern.isEmpty()) {
            status.text = "$action: IR code not configured yet. Add the captured pulse pattern in IrCommands.kt."
            return
        }
        try {
            val frequency = IrCommands.carrierFrequencyHz
            val supported = ir.carrierFrequencies
            if (supported != null && supported.none { frequency in it.minFrequency..it.maxFrequency }) {
                status.text = "The phone may not support ${frequency / 1000} kHz IR. Check IrCommands.kt."
                return
            }
            ir.transmit(frequency, pattern)
            status.text = "$action command sent."
        } catch (e: Exception) {
            status.text = "Couldn't send IR command: ${e.message ?: "unsupported IR pattern"}"
        }
    }

    private fun listener(onStop: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {}
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {
            onStop(seekBar?.progress ?: 0)
        }
    }

    private fun sectionTitle(value: String) = TextView(this).apply {
        text = value
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(0xFF4D5B70.toInt())
        setPadding(0, dp(8), 0, dp(6))
    }

    private fun label(value: String) = TextView(this).apply {
        text = value
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(0xFF172033.toInt())
        setPadding(0, dp(3), 0, dp(4))
    }

    private fun marginParams(bottom: Int = 0) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(bottom) }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
